const botones_aplicar = document.querySelectorAll('.button-apply-job')

/* botones_aplicar.forEach(boton => {
    boton.addEventListener('click', () => {
    boton.textContent = '¡Aplicado!'
    boton.classList.add('is-applied')
    boton.disabled = true
});

}) */

const joblistol = document.querySelector('.joblist')

joblistol.addEventListener('click', function(event) {
    const element = event.target

    if (element.classList.contains('button-apply-job')) {
        element.textContent = '¡Aplicado!'
        element.classList.add('is-applied')
        element.disabled = true
    }
})

const filter = document.querySelector('#filter-location')
const jobcards = document.querySelectorAll('.jobcard')

filter.addEventListener('change', function() {
    const selectedLocation = filter.value

    jobcards.forEach(job => {
        const modalidad = job.dataset.modalidad

        if (selectedLocation === '' || selectedLocation === modalidad) {
            job.style.display = 'block'
        } else {
            job.style.display = 'none'
        }
    })
})